用户头像更换
<image class="userinfo-avatar" src="{{userInfo.avatarUrl}}"></image>


